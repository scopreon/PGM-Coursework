Usage of pgmEcho (echoes file from input to output):
./pgmEcho input_file.pgm output_file.pgm
Usage of pgmComp (compares input file and output file):
./pgmComp input_file.pgm output_file.pgm
Usage of pgma2b (convert ascii file to binary):
./pgma2b input_file.pgm output_file.pgm
Usage of pgmb2a (convert binary file to ascii):
./pgmb2a input_file.pgm output_file.pgm
Usage of pgmReduce (reduces file in size by factor n):
./pgmReduce input_file.pgm factor output_file.pgm
